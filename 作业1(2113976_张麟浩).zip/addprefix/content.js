// content.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === 'addPrefix') {
    document.title = 'Custom Prefix - ' + document.title;
  }
});
